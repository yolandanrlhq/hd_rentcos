<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/produkAdmin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="main-content">
            <header class="main-header">
                <h2>Daftar Produk</h2>
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search for...">
                </div>
                <a href="<?php echo e(route('admin.create')); ?>" class="add-button">
                    Tambah Kostum
                    <i class="fas fa-plus-circle"></i>
                </a>

            </header>

            <section class="data-table-section">
                <div class="table-info">
                    <span class="status">semua produk</span>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>nama</th>
                                <th>kategori</th>
                                <th>harga</th>
                                <th>stok</th>
                                <th>ukuran</th>
                                <th>deskripsi</th>
                                <th>foto</th>
                                <th>aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id_produk); ?></td>
                                <td><?php echo e($item->nama_produk); ?></td>
                                <td><?php echo e($item->kategori->nama_kategori); ?></td>
                                <td>Rp<?php echo e(number_format($item->harga_produk, 0, ',', '.')); ?></td>
                                <td><?php echo e($item->stok_produk); ?></td>

                                <!-- ====== TAMPILKAN SEMUA UKURAN PRODUK ====== -->
                                <td>
                                    <?php if($item->ukuran->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $item->ukuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge-ukuran"><?php echo e($u->nama_ukuran); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <span>-</span>
                                    <?php endif; ?>
                                </td>

                                <!-- ====== DESKRIPSI PRODUK (PENDEK) ====== -->
                                <td style="max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    <?php echo e($item->deskripsi ?? '-'); ?>

                                </td>

                                <!-- ====== FOTO PRODUK ====== -->
                                <td>
                                    <?php if($item->foto): ?>
                                    <img src="<?php echo e(asset('storage/'.$item->foto)); ?>" width="50" alt="<?php echo e($item->nama_produk); ?>">
                                    <?php else: ?>
                                    Tidak ada
                                    <?php endif; ?>
                                </td>

                                <!-- ====== AKSI ====== -->
                                <td>
                                    <a href="<?php echo e(route('admin.editProduk', $item->id_produk)); ?>"><i class="fas fa-pen"></i></a>
                                    <form action="<?php echo e(route('admin.produk.destroy', $item->id_produk)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-delete" onclick="return confirm('Yakin hapus produk ini?')"><i class="fa-solid fa-trash"></i></button  >
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="pagination-wrapper" style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                        <!-- Info -->
                        <span class="table-count">
                            <?php echo e($produk->firstItem() ?? 0); ?>-<?php echo e($produk->lastItem() ?? 0); ?> of <?php echo e($produk->total()); ?>

                        </span>

                        <!-- Controls -->
                        <div class="pagination-controls" style="display: flex; align-items: center; gap: 8px;">
                            <span>Rows per page:</span>
                            <span class="row-count">10</span>

                            <!-- Previous -->
                            <?php if($produk->onFirstPage()): ?>
                                <button class="nav-button disabled"><i class="fas fa-angle-left"></i></button>
                            <?php else: ?>
                                <a href="<?php echo e($produk->previousPageUrl()); ?>" class="nav-button"><i class="fas fa-angle-left"></i></a>
                            <?php endif; ?>

                            <!-- Next -->
                            <?php if($produk->hasMorePages()): ?>
                                <a href="<?php echo e($produk->nextPageUrl()); ?>" class="nav-button"><i class="fas fa-angle-right"></i></a>
                            <?php else: ?>
                                <button class="nav-button disabled"><i class="fas fa-angle-right"></i></button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
     </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/produk.blade.php ENDPATH**/ ?>