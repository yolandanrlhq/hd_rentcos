<?php $__env->startSection('title', 'Keranjang - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="cart-page">
    <div class="cart-container">
        <h2><i class="fas fa-shopping-cart"></i> Keranjang Saya</h2>

        <!-- HEADER -->
        <div class="cart-header">
        <span>Pilih</span>
        <span>Produk</span>
        <span>Harga</span>
        <span>Kuantitas</span>
        <span>Total</span>
        <span>Aksi</span>
        </div>

        <!-- ITEM -->
        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cart-item" id="cart-item-<?php echo e($item->id); ?>">

            <div class="cart-col center">
            <input type="checkbox" class="select-item" value="<?php echo e($item->id); ?>">
            </div>

            <div class="cart-col product">
            <img src="<?php echo e(asset('storage/' . $item->produk->foto)); ?>" alt="">
            <div>
                <strong><?php echo e($item->produk->nama_produk); ?></strong>
                <p>Ukuran : <strong><?php echo e($item->ukuran); ?></strong></p>
            </div>
            </div>

            <div class="cart-col price" id="price-<?php echo e($item->id); ?>">
            Rp<?php echo e(number_format($item->harga_satuan,0,',','.')); ?>

            </div>

            <div class="cart-col qty">
            <button onclick="updateQty(<?php echo e($item->id); ?>, -1, <?php echo e($item->harga_satuan); ?>)">-</button>
            <span id="qty-<?php echo e($item->id); ?>"><?php echo e($item->jumlah); ?></span>
            <button onclick="updateQty(<?php echo e($item->id); ?>, 1, <?php echo e($item->harga_satuan); ?>)">+</button>
            </div>

            <div class="cart-col total" id="total-<?php echo e($item->id); ?>">
            Rp<?php echo e(number_format($item->harga_satuan * $item->jumlah,0,',','.')); ?>

            </div>

            <div class="cart-col center">
            <form action="<?php echo e(route('cart.destroy', $item->id)); ?>" method="POST">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="hapus-btn">Hapus</button>
            </form>
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- SUMMARY -->
        <div class="cart-summary">
        <label class="select-all-wrapper">
            <input type="checkbox" id="select-all">
            <span>Pilih Semua</span>
        </label>

        <p class="summary-total">
            Total (<span id="summary-count"><?php echo e($cartItems->count()); ?></span>):
            <strong>Rp<?php echo e(number_format($total,0,',','.')); ?></strong>
        </p>

        <div style="display: flex; flex-direction: column; gap: 10px;">
            <button class="checkout-btn" onclick="proceedToCheckout()">Checkout</button>
            <a href="<?php echo e(route('cart.status')); ?>" class="checkout-btn">Lihat Status Penyewaan</a>
        </div>
        </div>
    </div>
    </main>

    <script>
    // ================= UPDATE QTY =================
    function updateQty(id, change, hargaSatuan) {
        let qtySpan = document.getElementById(`qty-${id}`);
        let qty = parseInt(qtySpan.textContent) + change;
        if (qty < 1) return;

        fetch(`/user/cart/update/${id}`, {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({ jumlah: qty })
        })
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                alert(data.message || 'Gagal update qty');
                return;
            }

            // Update qty & total per item
            qtySpan.textContent = qty;
            document.getElementById(`total-${id}`).textContent =
                'Rp' + (hargaSatuan * qty).toLocaleString('id-ID');

            // Re-calculate summary berdasarkan item yang dicentang
            updateSummaryBySelection();
        });
    }



    // ================= CHECKOUT =================
    function proceedToCheckout() {
        const checked = Array.from(document.querySelectorAll('.select-item:checked'))
                            .map(cb => cb.value);

        if (checked.length === 0) {
            alert('Pilih minimal satu produk untuk checkout');
            return;
        }

        const base = '<?php echo e(route('cart.checkout')); ?>';
        const params = checked.map(id => 'selected[]=' + encodeURIComponent(id)).join('&');
        window.location.href = base + (base.includes('?') ? '&' : '?') + params;
    }

    // ================= PILIH SEMUA =================
    function toggleSelectAll(checked) {
        document.querySelectorAll('.select-item').forEach(cb => cb.checked = checked);
    }

    // ================= UPDATE RINGKASAN TOTAL =================
    function updateSummaryBySelection() {
        const checkedItems = Array.from(document.querySelectorAll('.select-item:checked'));

        let totalHarga = 0;
        let jumlahItem = checkedItems.length;

        checkedItems.forEach(cb => {
            const id = cb.value;
            const qty = parseInt(document.getElementById(`qty-${id}`).textContent);
            const harga = parseInt(
                document.getElementById(`price-${id}`).textContent.replace(/[^\d]/g, '')
            );

            totalHarga += qty * harga;
        });

        document.querySelector('.summary-total strong').textContent =
            'Rp' + totalHarga.toLocaleString('id-ID');

        document.getElementById('summary-count').textContent = jumlahItem;
    }

    // ================= INISIALISASI =================
    document.addEventListener('DOMContentLoaded', function () {
        const selectAll = document.getElementById('select-all');
        const items = document.querySelectorAll('.select-item');

        // Select All listener
        if (selectAll) {
            selectAll.addEventListener('change', function () {
                toggleSelectAll(this.checked);
                updateSummaryBySelection();
            });
        }

        // Listener per item
        items.forEach(cb => cb.addEventListener('change', function () {
            const allChecked = Array.from(items).every(i => i.checked);
            if (selectAll) selectAll.checked = allChecked;
            updateSummaryBySelection();
        }));

        // Set total awal = 0 (tidak ada centang)
        updateSummaryBySelection();
    });
    </script>
    <?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/cart.blade.php ENDPATH**/ ?>