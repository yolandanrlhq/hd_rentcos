<?php $__env->startSection('title', 'Wishlist - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/wishlist.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="hero-collection">
    <h2>Wishlist Anda</h2>

    <?php if($wishlists->isEmpty()): ?>
        <p class="empty-wishlist">Wishlist kamu masih kosong ❤️</p>
    <?php else: ?>
        <div class="cards">
            <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <a href="<?php echo e(route('user.produk.show', $item->produk->id_produk)); ?>">
                        <img
                            src="<?php echo e(asset('storage/' . $item->produk->foto)); ?>"
                            alt="<?php echo e($item->produk->nama_produk); ?>"
                        >
                        <h3><?php echo e($item->produk->nama_produk); ?></h3>
                        <p>
                            Rp<?php echo e(number_format($item->produk->harga_produk, 0, ',', '.')); ?>

                        </p>
                    </a>

                    <!-- toggle wishlist (hapus) -->
                    <form
                        action="<?php echo e(route('wishlist.toggle')); ?>"
                        method="POST"
                        class="wishlist-remove-form"
                    >
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_produk" value="<?php echo e($item->produk->id_produk); ?>">
                        <button type="submit" class="remove-btn" title="Hapus dari wishlist">
                            💔
                        </button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</section>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/wishlist.blade.php ENDPATH**/ ?>