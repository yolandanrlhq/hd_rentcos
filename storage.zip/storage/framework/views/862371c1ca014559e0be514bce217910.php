<?php $__env->startSection('title', 'Edit Pengembalian Kostum'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/editPengembalian.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <h2>Edit Pengembalian #<?php echo e($pengembalian->sewa->id); ?></h2>

        
        <?php if(session('success')): ?>
            <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        
        <?php if($errors->any()): ?>
            <div class="alert-error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.pengembalian.update', $pengembalian->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label>Status</label>
                <select name="status" class="select-field" required>
                    <?php $__currentLoopData = ['belum_dikembalikan','dikembalikan','dicek_admin','selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(old('status', $pengembalian->status) == $status ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst(str_replace('_',' ', $status))); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label>Denda (Rp)</label>
                <input type="number" name="denda" class="input-field" value="<?php echo e(old('denda', $pengembalian->denda)); ?>">
            </div>

            <div class="form-group">
                <label>Catatan Admin</label>
                <textarea name="catatan_admin" class="textarea-field"><?php echo e(old('catatan_admin', $pengembalian->catatan_admin)); ?></textarea>
            </div>

            <div class="form-group">
                <label>Bukti Foto</label>
                <input type="file" name="bukti_foto" class="input-file">
                <?php if($pengembalian->bukti_foto): ?>
                    <p>Foto Saat Ini: <a href="<?php echo e(asset('storage/' . $pengembalian->bukti_foto)); ?>" target="_blank">Lihat</a></p>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn-primary">Update Pengembalian</button>
        </form>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/editPengembalian.blade.php ENDPATH**/ ?>