<?php $__env->startSection('title', 'Checkout - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/checkout.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="checkout-container">
  <h2>Checkout</h2>

  <!-- Alamat Pengiriman -->
  <section class="alamat-box">
    <div class="alamat-header">
      <i class="ri-map-pin-user-fill"></i>
      <span>Alamat Pengiriman</span>
    </div>
    <div class="alamat-info">
      <div class="nama">
        <strong><?php echo e(auth()->user()->name); ?></strong>
        <span><?php echo e(auth()->user()->phone ?? ''); ?></span>
      </div>
      <div class="alamat">
        <?php echo nl2br(e(auth()->user()->address ?? '')); ?>

      </div>
      <a href="<?php echo e(route('user.profile')); ?>" class="ubah">Ubah</a>
    </div>
  </section>

  <!-- Produk -->
  <section class="produk-box">
    <table>
      <thead>
        <tr>
          <th>Kostum disewa</th>
          <th>Harga</th>
          <th>Satuan</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = ($items ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr data-item-id="<?php echo e($item->id); ?>">
          <td class="produk-info">
            <img src="<?php echo e(asset('storage/' . ($item->produk->foto ?? ''))); ?>" alt="<?php echo e($item->produk->nama_produk); ?>">
            <span><?php echo e($item->produk->nama_produk); ?> <?php if($item->ukuran): ?> (<?php echo e($item->ukuran); ?>) <?php endif; ?></span>
          </td>
          <td>Rp<?php echo e(number_format($item->harga_satuan,0,',','.')); ?></td>
          <td><?php echo e($item->jumlah); ?></td>
          <td class="row-total" id="total-<?php echo e($item->id); ?>">Rp<?php echo e(number_format($item->harga_satuan * $item->jumlah,0,',','.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </section>

  <!-- Metode Pengiriman -->
    <section class="pembayaran-box">
        <form id="checkout-form" method="POST" action="<?php echo e(route('cart.sewa')); ?>">
            <?php echo csrf_field(); ?>

            <!-- Tanggal Sewa -->
            <section class="tanggal-sewa-box">
                <div class="tanggal-input">
                    <h3>📅 Jadwal Sewa</h3>
                    <small class="hint">
                    Pilih tanggal mulai penyewaan kostum
                    </small>

                    <label for="tanggal_sewa">Mulai Sewa</label>
                    <input
                        type="date"
                        name="tanggal_sewa"
                        id="tanggal_sewa"
                        required
                        min="<?php echo e(now()->toDateString()); ?>"
                    >

                    <label for="tanggal_kembali">Tanggal Kembali</label>
                    <input
                        type="date"
                        name="tanggal_kembali"
                        id="tanggal_kembali"
                        required
                        readonly
                    >
                </div>
            </section>

            <!-- Metode Pengiriman -->
            <h3>Metode Pengiriman</h3>

            <div class="payment-methods">
            <button type="button" data-method="cod" class="active">COD</button>
            <button type="button" data-method="ambil_ditempat">Ambil ditempat</button>
            <button type="button" data-method="antar_ke_rumah">Antar ke rumah</button>
            <button type="button" data-method="via_ekspedisi">Via ekspedisi</button>
            </div>

            <input type="hidden" name="delivery_method" id="delivery_method" value="cod">

            <!-- Ringkasan -->
            <div class="payment-summary">
            <div>
                <span>Subtotal</span>
                <span id="subtotal">Rp<?php echo e(number_format($subtotal)); ?></span>
            </div>
            <hr>
            <div class="total">
                <span>Total Pembayaran</span>
                <span class="red" id="total-bayar">Rp<?php echo e(number_format($subtotal)); ?></span>
            </div>
            </div>

            <!-- Hidden Selected -->
            <?php $__currentLoopData = request()->query('selected', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" name="selected[]" value="<?php echo e($id); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="submit" class="checkout-btn">Sewa Sekarang</button>
        </form>
    </section>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const buttons = document.querySelectorAll('.payment-methods button');
  const hiddenInput = document.getElementById('delivery_method');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      hiddenInput.value = btn.dataset.method;
    });
  });
});

document.addEventListener('DOMContentLoaded', () => {
    const tanggalSewa = document.getElementById('tanggal_sewa');
    const tanggalKembali = document.getElementById('tanggal_kembali');

    tanggalSewa.addEventListener('change', () => {
        if(tanggalSewa.value){
            const sewaDate = new Date(tanggalSewa.value);
            const kembaliDate = new Date(sewaDate);
            kembaliDate.setDate(sewaDate.getDate() + 1); // +1 hari
            const yyyy = kembaliDate.getFullYear();
            const mm = String(kembaliDate.getMonth() + 1).padStart(2, '0');
            const dd = String(kembaliDate.getDate()).padStart(2, '0');
            tanggalKembali.value = `${yyyy}-${mm}-${dd}`;
        } else {
            tanggalKembali.value = '';
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/checkout.blade.php ENDPATH**/ ?>