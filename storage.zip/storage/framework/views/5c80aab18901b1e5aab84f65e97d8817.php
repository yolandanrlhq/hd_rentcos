<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/editProduk.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="main-content">
        <div class="form-container">
            <h2>Edit Produk</h2>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger" style="background-color:#f8d7da; color:#721c24; padding:10px; border-radius:5px; margin-bottom:15px;">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger" style="background-color:#f8d7da; color:#721c24; padding:10px; border-radius:5px; margin-bottom:15px;">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.produk.update', $produk->id_produk)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="nama_produk">Nama Produk</label>
                    <input type="text" name="nama_produk" id="nama_produk" value="<?php echo e(old('nama_produk', $produk->nama_produk)); ?>" required>
                </div>

                <div class="form-group">
                    <label for="kategori_id">Kategori</label>
                    <select name="id_kategori" id="id_kategori" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id_kategori); ?>" <?php echo e(old('id_kategori', $produk->id_kategori) == $item->id_kategori ? 'selected' : ''); ?>>
                                <?php echo e($item->nama_kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="harga_produk">Harga</label>
                    <input type="number" name="harga_produk" id="harga_produk" value="<?php echo e(old('harga_produk', $produk->harga_produk)); ?>" required>
                </div>

                <div class="form-group">
                    <label for="stok_produk">Stok Total</label>
                    <input type="number" name="stok_produk" id="stok_produk" value="<?php echo e(old('stok_produk', $produk->stok_produk)); ?>" placeholder="Total stok (opsional, bisa dihitung dari ukuran)" required>
                </div>

                <div class="form-group">
                    <label>Ukuran Produk & Stok</label>
                    <div id="ukuran-wrapper">
                        <?php if(old('ukuran')): ?>
                            <?php $__currentLoopData = old('ukuran'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="ukuran-item">
                                    <input type="text" name="ukuran[<?php echo e($index); ?>][nama_ukuran]" value="<?php echo e($ukuran['nama_ukuran']); ?>" placeholder="Ukuran (misal: S)" required>
                                    <input type="number" name="ukuran[<?php echo e($index); ?>][stok]" value="<?php echo e($ukuran['stok']); ?>" placeholder="Stok ukuran ini" required>
                                    <button type="button" class="btn-remove" onclick="hapusUkuran(this)">❌</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $produk->ukuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="ukuran-item">
                                    <input type="text" name="ukuran[<?php echo e($index); ?>][nama_ukuran]" value="<?php echo e($ukuran->nama_ukuran); ?>" placeholder="Ukuran (misal: S)" required>
                                    <input type="number" name="ukuran[<?php echo e($index); ?>][stok]" value="<?php echo e($ukuran->stok); ?>" placeholder="Stok ukuran ini" required>
                                    <button type="button" class="btn-remove" onclick="hapusUkuran(this)">❌</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" id="btn-tambah-ukuran" class="btn-add">+ Tambah Ukuran</button>
                </div>

                <div class="form-group">
                    <label for="deskripsi">Deskripsi Produk</label>
                    <textarea name="deskripsi" id="deskripsi" rows="4" placeholder="Tulis deskripsi produk..."><?php echo e(old('deskripsi', $produk->deskripsi)); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="fotos">Foto Produk Baru</label>
                    <input type="file" name="fotos[]" id="fotos" accept="image/*" multiple>
                </div>

                <div class="form-group">
                    <label>Foto Produk Lama</label>
                    <div class="existing-photos">
                        <?php $__currentLoopData = $produk->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('storage/' . $foto->foto_path)); ?>" alt="Foto Produk" style="width: 80px; height: 80px; object-fit: cover; margin-right: 5px;">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-submit">Perbarui</button>
                    <a href="<?php echo e(route('admin.produk')); ?>" class="btn-cancel">Batal</a>
                </div>
            </form>
        </div>

        <script>
        document.getElementById('btn-tambah-ukuran').addEventListener('click', function() {
            const wrapper = document.getElementById('ukuran-wrapper');
            const index = wrapper.querySelectorAll('.ukuran-item').length;
            const div = document.createElement('div');
            div.classList.add('ukuran-item');
            div.innerHTML = `
                <input type="text" name="ukuran[${index}][nama_ukuran]" placeholder="Ukuran (misal: M)" required>
                <input type="number" name="ukuran[${index}][stok]" placeholder="Stok ukuran ini" required>
                <button type="button" class="btn-remove" onclick="hapusUkuran(this)">❌</button>
            `;
            wrapper.appendChild(div);
        });

        function hapusUkuran(button) {
            button.parentElement.remove();
        }

        // Fungsi untuk update stok total
        function updateStokTotal() {
            const stokInputs = document.querySelectorAll('#ukuran-wrapper input[name$="[stok]"]');
            let total = 0;
            stokInputs.forEach(input => {
                const value = parseInt(input.value) || 0;
                total += value;
            });
            document.getElementById('stok_produk').value = total;
        }

        // Jalankan update saat stok ukuran berubah
        document.getElementById('ukuran-wrapper').addEventListener('input', function(e) {
            if (e.target.name.endsWith('[stok]')) {
                updateStokTotal();
            }
        });

        // Jalankan update saat halaman dimuat
        updateStokTotal();
        </script>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/editProduk.blade.php ENDPATH**/ ?>