<?php $__env->startSection('title', 'Detail Produk - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/profilUser.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="profile-section">
        <div class="profile-card">
            <!-- Kiri: Foto Profil -->
            <div class="profile-left">
            <div class="profile-img-wrapper">
                <img
                src="<?php echo e($user->foto ? asset('storage/' . $user->foto) : asset('assets/default-profile.jpg')); ?>"
                alt="Foto Profil"
                id="previewImg"
                >
            </div>

            <h2 class="profile-name"><?php echo e($user->name); ?></h2>
            <p class="profile-location"><?php echo e($user->address ?? 'Belum ada alamat'); ?></p>
            </div>

            <!-- Kanan: Detail Profil -->
            <div class="profile-right">
            <div class="profile-header">
                <h3>Informasi Akun</h3>
                <a href="<?php echo e(route('user.editProfile')); ?>" class="edit-btn">
                <i class="ri-edit-line"></i> Edit
                </a>
            </div>

            <div class="profile-details">
                <p><span>Email :</span> <?php echo e($user->email); ?></p>
                <p><span>No. Telepon :</span> <?php echo e($user->phone ?? '-'); ?></p>
                <p><span>Alamat :</span> <?php echo e($user->address ?? '-'); ?></p>
                <p><span>Bergabung Sejak :</span> <?php echo e(\Carbon\Carbon::parse($user->created_at)->translatedFormat('F Y')); ?></p>
            </div>
            </div>
        </div>
    </main>
    <?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/profil.blade.php ENDPATH**/ ?>