<?php $__env->startSection('title', 'Notifikasi - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/notifikasi.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="notifikasi-container">
    <h2>Notifikasi</h2>

    <?php if($notifications->isEmpty()): ?>
        <p>Tidak ada notifikasi.</p>
    <?php else: ?>
        <div class="notifikasi-list">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="notifikasi-item <?php echo e($notif->is_read ? '' : 'new'); ?>">
                    <i class="ri-<?php echo e($notif->ikon ?? 'notification-3-fill'); ?> icon"></i>

                    <div class="notifikasi-text">
                        <h4><?php echo e($notif->judul); ?></h4>
                        <p><?php echo e($notif->pesan); ?></p>
                        <span class="time">
                            <?php echo e($notif->created_at->diffForHumans()); ?>

                        </span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</main>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/notifikasi.blade.php ENDPATH**/ ?>