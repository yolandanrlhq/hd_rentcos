<header class="navbar">
    <a href="<?php echo e(route('user.dashboard')); ?>" class="logo">HD <span>RENTCOS</span></a>

    <nav class="nav-links">
      <a href="<?php echo e(route('user.produk')); ?>" class="<?php echo e(request()->routeIs('user.sections.produk') ? 'active' : ''); ?>">Produk</a>
      <a href="<?php echo e(route('user.jadwalEvent')); ?>" class="<?php echo e(request()->routeIs('user.jadwalEvent') ? 'active' : ''); ?>">Jadwal Event</a>
      <a href="<?php echo e(route('wishlist.index')); ?>" class="<?php echo e(request()->routeIs('user.wishlist') ? 'active' : ''); ?>">Wishlist</a>
    </nav>

    <div class="search-box">
      <i class="fas fa-search"></i>
      <input type="text" placeholder="Search">
    </div>

    <div class="icons">
        <a href="<?php echo e(route('user.notifikasi')); ?>" class="notif-icon">
            <i class="ri-notification-3-fill"></i>

            <?php if(isset($unreadCount) && $unreadCount > 0): ?>
                <span class="notif-badge"><?php echo e($unreadCount); ?></span>
            <?php endif; ?>
        </a>

        <a href="<?php echo e(route('cart.index')); ?>">
            <i class="ri-shopping-cart-fill"></i>
        </a>

        <a href="<?php echo e(route('user.chat')); ?>">
            <i class="ri-message-3-fill"></i>
        </a>
    </div>


    <div class="profil dropdown">
        <button class="profile-btn" id="profileToggle">
            <i class="ri-user-3-fill"></i>
        </button>

        <div class="dropdown-menu" id="profileMenu">
            <a href="<?php echo e(route('user.profile')); ?>">
                <i class="ri-user-line"></i> Lihat Profil
            </a>

            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="logout-btn">
                    <i class="ri-logout-box-r-line"></i> Logout
                </button>
            </form>
        </div>
    </div>
  </header>
<?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/sections/header.blade.php ENDPATH**/ ?>