<div class="dashboard-container">
    <aside class="sidebar">
        <h1 class="logo">HDRENTCOS</h1>
            <nav class="nav-menu">
                <ul>
                    <li class="<?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-home"></i> Dasbor</a></li>
                    <li class="<?php echo e(request()->routeIs('admin.produk') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.produk')); ?>"><i class="fas fa-box"></i> Produk</a></li>
                    <li class="<?php echo e(request()->routeIs('admin.event') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.event.index')); ?>"><i class="fas fa-calendar-alt"></i> Event</a></li>
                    <li class="<?php echo e(request()->routeIs('admin.pesanan') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.pesanan')); ?>"><i class="fas fa-file-alt"></i> Pesanan</a></li>
                    <li class="<?php echo e(request()->routeIs('admin.pengembalian.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.pengembalian.index')); ?>"><i class="fas fa-undo-alt"></i> Pengembalian</a></li>
                    <li class="<?php echo e(request()->routeIs('admin.user') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.users')); ?>"><i class="fas fa-user-friends"></i> User</a></li>
                    <li class="<?php echo e(request()->routeIs('admin.pesan') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.pesan')); ?>"><i class="fas fa-envelope"></i> Pesan</a></li>
                    <li class="<?php echo e(request()->routeIs('admin.iotControl') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.iotControl')); ?>"><i class="fa-solid fa-wrench"></i> IoT Control</a></li>
                    <li>
    <form action="<?php echo e(route('admin.logout')); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin logout?')">
        <?php echo csrf_field(); ?>
        <button type="submit" style="background:none;border:none;color:inherit;cursor:pointer;">
            <i class="fas fa-sign-out-alt"></i> Logout
        </button>
    </form>
</li>

                </ul>
            </nav>
    </aside>
</div>
<?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/sections/sidebar.blade.php ENDPATH**/ ?>