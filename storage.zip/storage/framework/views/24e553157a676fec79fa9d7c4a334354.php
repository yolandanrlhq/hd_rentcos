<?php $__env->startSection('title', 'Pengembalian Kostum'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/pengembalian.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="main-content">
        <h2>Daftar Pengembalian</h2>

        <?php if(session('success')): ?>
            <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>ID Sewa</th>
                    <th>User</th>
                    <th>Tanggal Sewa</th>
                    <th>Tanggal Kembali</th>
                    <th>Status Pengembalian</th>
                    <th>Denda</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pengembalians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($p->sewa->id); ?></td>
                    <td><?php echo e($p->sewa->user->name); ?></td>
                    <td><?php echo e($p->sewa->tanggal_sewa); ?></td>
                    <td><?php echo e($p->tanggal_dikembalikan); ?></td>
                    <td>
                    <span class="badge-status badge-<?php echo e($p->status); ?>">
                        <?php echo e(ucfirst(str_replace('_',' ', $p->status))); ?>

                    </span>
                </td>
                    <td><?php echo e($p->denda ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.pengembalian.edit', $p->id)); ?>">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Belum ada pengembalian</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php echo e($pengembalians->links()); ?>

    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/pengembalian.blade.php ENDPATH**/ ?>