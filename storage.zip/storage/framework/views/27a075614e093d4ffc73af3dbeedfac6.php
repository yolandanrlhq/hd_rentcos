<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/jadwalEventAdmin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="main-content">
            <header class="main-header">
                <h2>EVENT</h2>
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search for...">
                </div>
                <a href="<?php echo e(route('admin.event.create')); ?>" class="add-button">
                    Tambah Event
                    <i class="fas fa-plus-circle"></i>
                </a>
            </header>

            <section class="data-table-section">
                <div class="table-info">
                    <span class="status">semua event</span>

                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>nama</th>
                                <th>tempat</th>
                                <th>tgl</th>
                                <th>htm</th>
                                <th>kontak</th>
                                <th>foto</th>
                                <th>aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($event->id_event); ?></td>
                            <td><?php echo e($event->nama_event); ?></td>
                            <td class="tempat-event"><?php echo e($event->tempat_event); ?></td>
                            <td><?php echo e(date('Y-m-d', strtotime($event->tgl_event))); ?></td>
                            <td><?php echo e($event->htm); ?></td>
                            <td><?php echo e($event->kontak_panitia); ?></td>
                            <td>
                                <?php if($event->gambar): ?>
                                <img src="<?php echo e(asset('storage/'.$event->gambar)); ?>" width="50" alt="<?php echo e($event->gambar); ?>">
                                <?php else: ?>
                                Tidak ada
                                <?php endif; ?>
                            </td>
                            <td>
                                <!-- Edit -->
                                <a href="<?php echo e(route('admin.event.edit', $event->id_event)); ?>">
                                    <i class="fas fa-pen"></i>
                                </a>

                                <!-- Delete -->
                                <form action="<?php echo e(route('admin.event.destroy', $event->id_event)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-delete" onclick="return confirm('Yakin hapus event ini?')">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <div class="pagination-wrapper" style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                <span class="table-count">
                    <?php echo e($events->firstItem() ?? 0); ?>-<?php echo e($events->lastItem() ?? 0); ?> of <?php echo e($events->total()); ?>

                </span>
                <div class="pagination-controls">
                    <span>Rows per page:</span>
                    <span class="row-count"><?php echo e($events->perPage()); ?></span>

                    <?php if($events->onFirstPage()): ?>
                        <button class="nav-button disabled"><i class="fas fa-angle-left"></i></button>
                    <?php else: ?>
                        <a href="<?php echo e($events->previousPageUrl()); ?>" class="nav-button"><i class="fas fa-angle-left"></i></a>
                    <?php endif; ?>

                    <?php if($events->hasMorePages()): ?>
                        <a href="<?php echo e($events->nextPageUrl()); ?>" class="nav-button"><i class="fas fa-angle-right"></i></a>
                    <?php else: ?>
                        <button class="nav-button disabled"><i class="fas fa-angle-right"></i></button>
                    <?php endif; ?>
                </div>
            </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/jadwalEvent.blade.php ENDPATH**/ ?>