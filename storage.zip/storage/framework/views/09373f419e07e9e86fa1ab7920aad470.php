<?php $__env->startSection('title', 'Produk - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/produkUser.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="products-section">
    <div class="container">
        <h2 class="section-title">Produk Kami</h2>

        <div class="products-grid">
            <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $avg   = round($produk->testimonis_avg_rating ?? 0, 1);
                    $total = $produk->testimonis_count ?? 0;

                    $full = floor($avg);
                    $half = ($avg - $full) >= 0.5;
                ?>

                <a href="<?php echo e(route('user.produk.show', $produk->id_produk)); ?>">
                    <article class="product-card">
                        <div class="img-wrap">
                            <img
                                src="<?php echo e(asset('storage/' . $produk->foto)); ?>"
                                alt="<?php echo e($produk->nama_produk); ?>"
                            >
                        </div>

                        <div class="card-body">
                            <h3 class="product-title"><?php echo e($produk->nama_produk); ?></h3>

                            <!-- ===== RATING ===== -->
                            <div class="rating">
                                <div class="stars" aria-hidden="true">
                                    <?php for($i = 0; $i < $full; $i++): ?>
                                        ★
                                    <?php endfor; ?>

                                    <?php if($half): ?>
                                        ☆
                                    <?php endif; ?>

                                    <?php for($i = $full + ($half ? 1 : 0); $i < 5; $i++): ?>
                                        ☆
                                    <?php endfor; ?>
                                </div>

                                <span class="rating-score">
                                    <?php echo e($avg); ?>/5
                                    <small>(<?php echo e($total); ?>)</small>
                                </span>
                            </div>

                            <!-- ===== HARGA ===== -->
                            <div class="price-row">
                                <div class="price">
                                    Rp<?php echo e(number_format($produk->harga_produk, 0, ',', '.')); ?>

                                </div>
                                <div class="duration">/ 3 hari</div>
                            </div>
                        </div>
                    </article>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/produk.blade.php ENDPATH**/ ?>