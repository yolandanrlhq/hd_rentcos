<?php $__env->startSection('title', 'Beranda - HD RENTCOS'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- ================= HERO ================= -->
<section class="hero">
    <div class="hero-text">
        <h4>Cosplay for the Modern Hero</h4>
        <h1>Level Up Your Style <br> Like Your Favorite Hero</h1>
        <p>Sewa kostum cosplay berkualitas, tampil maksimal di setiap event.</p>
        <a href="<?php echo e(route('user.produk')); ?>">
            <button>Explore Kostum</button>
        </a>
    </div>
    <div class="hero-img">
        <img src="<?php echo e(asset('assets/heroImage.png')); ?>" alt="Hero Image">
    </div>
</section>

<!-- ================= REKOMENDASI ================= -->
<section class="hero-collection">
    <h2>Rekomendasi Kostum</h2>
    <p>Kostum favorit yang paling sering disewa</p>

    <div class="cards">
        <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <a href="<?php echo e(route('user.produk.show', $item->id_produk)); ?>">
                    <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" alt="<?php echo e($item->nama_produk); ?>">
                    <h3><?php echo e($item->nama_produk); ?></h3>
                    <p>Rp<?php echo e(number_format($item->harga_produk,0,',','.')); ?></p>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="lihat-semua-container">
        <a href="<?php echo e(route('user.produk')); ?>">
            <button class="lihat-semua-btn">Lihat Semua</button>
        </a>
    </div>
</section>

<!-- ================= TERBARU ================= -->
<section class="latest">
    <h2>Latest Arrivals</h2>
    <p>Koleksi terbaru kami</p>

    <div class="cards">
        <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <a href="<?php echo e(route('user.produk.show', $item->id_produk)); ?>">
                    <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" alt="<?php echo e($item->nama_produk); ?>">
                    <h3><?php echo e($item->nama_produk); ?></h3>
                    <p>Rp<?php echo e(number_format($item->harga_produk,0,',','.')); ?></p>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<!-- ================= TESTIMONI ================= -->
<section class="testimonials">
    <h2>Our Happy Customers</h2>
    <div class="reviews">
        <div class="review">
            <p>"Kostumnya bersih dan detail banget!"</p>
            <span>★★★★★</span>
        </div>
        <div class="review">
            <p>"Pelayanan cepat, recommended buat event."</p>
            <span>★★★★★</span>
        </div>
        <div class="review">
            <p>"Harga masuk akal, kualitas premium."</p>
            <span>★★★★☆</span>
        </div>
    </div>
</section>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/dashboard.blade.php ENDPATH**/ ?>