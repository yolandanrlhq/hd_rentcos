<?php $__env->startSection('title', 'Status Penyewaan - HD RENTCOS'); ?>
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/status.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="status-page">
    <div class="status-container">
        <h2><i class="fas fa-truck"></i> Status Penyewaan</h2>

        
        <div class="status-tabs">
            <?php
                $tabs = ['semua','menunggu_konfirmasi','diproses','dikirim','selesai','dibatalkan'];
            ?>
            <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('cart.status', ['status' => $tab])); ?>" class="<?php echo e(($filter == $tab || (!$filter && $tab=='semua')) ? 'active' : ''); ?>">
                    <?php echo e(ucfirst(str_replace('_',' ',$tab))); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <?php $__empty_1 = true; $__currentLoopData = $sewas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sewa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="status-card">

            
            <div class="status-left">
                <h3>Pesanan #<?php echo e($sewa->id); ?></h3>
                <p>Nama: <strong><?php echo e($sewa->user->name ?? '-'); ?></strong></p>
                <p>Tanggal Sewa: <strong><?php echo e($sewa->tanggal_sewa); ?></strong></p>
                <p>Status: <strong class="<?php echo e($sewa->status); ?>"><?php echo e(ucfirst(str_replace('_',' ',$sewa->status))); ?></strong></p>
                <p>Total: <strong>Rp<?php echo e(number_format($sewa->total_harga,0,',','.')); ?></strong></p>
            </div>

            
            <div class="status-right">
                <a href="<?php echo e(route('cart.detail', $sewa->id)); ?>" class="btn-detail">Detail</a>

                
                <?php if($sewa->pengembalian): ?>
                    <div class="return-status">
                        <p>Pengembalian:
                            <strong class="return <?php echo e($sewa->pengembalian->status); ?>">
                                <?php echo e(ucfirst(str_replace('_',' ', $sewa->pengembalian->status))); ?>

                            </strong>
                        </p>
                    </div>
                <?php endif; ?>

                
                <?php if($sewa->pengembalian && $sewa->pengembalian->status == 'selesai'): ?>
                    <?php if(!$sewa->testimoni): ?>
                        <a href="<?php echo e(route('user.testimoni.create', $sewa->id)); ?>" class="btn-testimoni">
                            Berikan Penilaian
                        </a>
                    <?php else: ?>
                        <div class="user-testimoni">
                            <strong>Testimoni Anda:</strong>
                            <p><?php echo e($sewa->testimoni->isi); ?></p>
                            <p>Rating: <?php echo e($sewa->testimoni->rating); ?> ⭐</p>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="no-data">Belum ada riwayat penyewaan.</p>
        <?php endif; ?>

        
        <div class="pagination-wrapper">
            <?php echo e($sewas->links()); ?>

        </div>
    </div>
</main>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/status.blade.php ENDPATH**/ ?>