<?php $__env->startSection('title', 'Berikan Testimoni'); ?>
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/testimoni.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="testimoni-page">
    <div class="testimoni-wrapper">
        <div class="testimoni-header">
            Testimoni untuk Pesanan #<?php echo e($sewa->id); ?>

        </div>

        <div class="testimoni-body">
            
            <?php if($sewa->testimoni): ?>
                <div class="testimoni-bubble testimoni-received">
                    <p><?php echo e($sewa->testimoni->isi); ?></p>
                    <small>Rating: <?php echo e($sewa->testimoni->rating); ?> ⭐</small>
                    <?php if($sewa->testimoni->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $sewa->testimoni->foto)); ?>" alt="Foto Testimoni" class="testimoni-img">
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            
            <?php if(!$sewa->testimoni): ?>
            <form action="<?php echo e(route('user.testimoni.store', $sewa->id)); ?>" method="POST" class="testimoni-form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <textarea name="isi" rows="3" placeholder="Tuliskan pengalamanmu..."></textarea>
                <label for="foto">Upload Foto (opsional):</label>
                <input type="file" name="foto" accept="image/*">
                <select name="rating">
                    <?php for($i=5; $i>=1; $i--): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?> ⭐</option>
                    <?php endfor; ?>
                </select>
                <button type="submit">Kirim</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/testimoni.blade.php ENDPATH**/ ?>