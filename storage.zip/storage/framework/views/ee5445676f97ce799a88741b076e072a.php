<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'HD RENTCOS'); ?></title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo e(asset('css/berandaUser.css')); ?>">

  <?php echo $__env->yieldContent('extra-css'); ?>
</head>
<body>

  <?php echo $__env->yieldContent('content'); ?>

    <script>
        const toggle = document.getElementById('profileToggle');
        const menu = document.getElementById('profileMenu');

        toggle.addEventListener('click', function (e) {
            e.stopPropagation();
            menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        });

        document.addEventListener('click', function () {
            menu.style.display = 'none';
        });
    </script>
</body>
</html>
<?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/layouts/user.blade.php ENDPATH**/ ?>