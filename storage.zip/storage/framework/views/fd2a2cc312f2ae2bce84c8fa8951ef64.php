<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $__env->yieldContent('title', 'HDRENTCOS Dashboard'); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/root.css')); ?>">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <?php echo $__env->yieldContent('extra-css'); ?>
</head>
<body>
      <?php echo $__env->yieldContent('content'); ?>
      <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/layouts/admin.blade.php ENDPATH**/ ?>