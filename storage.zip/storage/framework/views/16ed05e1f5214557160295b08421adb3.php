<?php $__env->startSection('title', 'Checkout - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/checkoutSuccess.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="success-container">
    <div class="success-box">
        <h2>🎉 Terima Kasih!</h2>
        <p>
            Form pesanan kamu berhasil terkirim.<br>
            Untuk melanjutkan pembayaran, silakan hubungi admin melalui chat.
        </p>

        <?php if(isset($sewa)): ?>
        <a href="<?php echo e(route('chat.order', $sewa)); ?>" class="btn-chat">
            💬 Lanjut ke Chat Admin
        </a>
        <?php else: ?>
        <span class="btn-chat-disabled">💬 Chat tidak tersedia</span>
        <?php endif; ?>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const container = document.querySelector('.success-container');

    // Tambahkan confetti
    for(let i = 0; i < 50; i++){
        const confetti = document.createElement('div');
        confetti.classList.add('confetti');
        confetti.style.left = Math.random()*100 + 'vw';
        confetti.style.background = `hsl(${Math.random()*360}, 70%, 60%)`;
        confetti.style.animationDuration = 2 + Math.random()*3 + 's';
        confetti.style.width = 5 + Math.random()*10 + 'px';
        confetti.style.height = confetti.style.width;
        container.appendChild(confetti);
    }
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/checkoutSuccess.blade.php ENDPATH**/ ?>