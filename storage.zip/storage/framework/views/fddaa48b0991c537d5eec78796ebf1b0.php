<?php $__env->startSection('title', 'Manajemen User'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/produkAdmin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <header class="main-header">
            <h2>Semua User</h2>

            <div class="search-bar">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Cari user...">
            </div>
        </header>

        <section class="data-table-section">
            <div class="table-info">
                <span class="status">semua user</span>
            </div>

            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAMA</th>
                            <th>EMAIL</th>
                            <th>NO HP</th>
                            <th>ALAMAT</th>
                            <th>ROLE</th>
                            <th>FOTO</th>
                            <th>TERDAFTAR</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>

                            <td><?php echo e($user->name); ?></td>

                            <td><?php echo e($user->email); ?></td>

                            <td><?php echo e($user->phone ?? '-'); ?></td>

                            <td style="max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo e($user->address ?? '-'); ?>

                            </td>

                            <td>
                                <span class="badge-ukuran">
                                    <?php echo e(strtoupper($user->role)); ?>

                                </span>
                            </td>

                            <td>
                                <?php if($user->foto): ?>
                                    <img src="<?php echo e(asset('storage/'.$user->foto)); ?>" width="40">
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php echo e($user->created_at
                                    ? $user->created_at->format('d-m-Y')
                                    : '-'); ?>

                            </td>

                            <td class="aksi">
                                <a href="#" class="btn-edit">
                                    <i class="fas fa-pen"></i>
                                </a>

                                <form action="#" method="POST" class="hapus-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-delete"
                                        onclick="return confirm('Yakin hapus user ini?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/users.blade.php ENDPATH**/ ?>