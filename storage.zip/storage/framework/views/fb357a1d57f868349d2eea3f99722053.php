<?php $__env->startSection('title', 'Detail Produk - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/pesanUser.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="profile-section">
    <div class="chat-wrapper">

        <!-- Header -->
        <div class="chat-header-user">
            <i class="fas fa-user-circle chat-avatar-user"></i>
            <div class="chat-user-info">
                <span class="chat-title">Chat Admin</span>
                <small class="chat-subtitle">Online • Balasan cepat</small>
            </div>
        </div>

        <!-- Chat Body -->
        <div id="chat-body" class="chat-body-user"></div>

        <!-- Input -->
        <div class="chat-input-user">
            <input
                id="message-input"
                type="text"
                placeholder="Ketik pesan..."
                autocomplete="off"
            >
            <button id="send-btn" class="send-btn">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>

    </div>
</main>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
<script>
    const CHAT_SEND_URL = "<?php echo e(route('user.chat.send')); ?>";
    const CHAT_MESSAGES_URL = "<?php echo e(route('user.chat.messages', ['adminId' => 1])); ?>";
    const CSRF_TOKEN = "<?php echo e(csrf_token()); ?>";
    const ADMIN_ID = 1;
</script>
<script>
    const CURRENT_USER_ID = <?php echo e(auth()->id()); ?>;
    const PUSHER_KEY = "<?php echo e(env('PUSHER_APP_KEY')); ?>";
    const PUSHER_CLUSTER = "<?php echo e(env('PUSHER_APP_CLUSTER')); ?>";
</script>
<script src="<?php echo e(asset('js/pesanUser.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/pesan.blade.php ENDPATH**/ ?>