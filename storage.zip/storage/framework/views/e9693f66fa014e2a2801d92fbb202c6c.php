<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/pesanAdmin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="main-content">
        <div class="message-container">

            <!-- LEFT SIDE – USER LIST -->
            <section class="contact-list-section">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" id="search-user" placeholder="Cari pelanggan...">
                </div>
                <div id="user-list" class="contact-list"></div>
            </section>

            <!-- RIGHT SIDE – CHAT AREA -->
            <section class="chat-area">
                <header class="chat-header" id="chat-header" style="display:none;">
                    <div class="chat-user-info">
                        <div class="chat-avatar"></div>
                        <div>
                            <span id="chat-user-name" class="chat-user-name"></span>
                            <span id="chat-user-status" class="chat-user-status"></span>
                        </div>
                    </div>
                </header>

                <div id="chat-body" class="chat-body">
                    <div id="empty-chat-state" class="empty-chat-state">
                        <div class="empty-chat-box">
                            <div class="empty-chat-icon">
                                <i class="fas fa-comments"></i>
                            </div>
                            <h3>Belum ada percakapan</h3>
                            <p>Pilih pelanggan di sebelah kiri untuk mulai membalas pesan.</p>
                        </div>
                    </div>

                </div>

                <div id="chat-input-area" class="chat-input-placeholder" style="display:none;">
                    <input type="text" id="admin-chat-input" placeholder="Ketik pesan...">
                    <button id="admin-send-btn"><i class="fas fa-paper-plane"></i></button>
                </div>
            </section>
        </div>
    </main>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
        const ADMIN_CHAT_SEND_URL = "<?php echo e(route('admin.chat.send')); ?>";
        const CSRF_TOKEN_ADMIN = "<?php echo e(csrf_token()); ?>";
        const PUSHER_KEY = "<?php echo e(env('PUSHER_APP_KEY')); ?>";
        const PUSHER_CLUSTER = "<?php echo e(env('PUSHER_APP_CLUSTER')); ?>";
    </script>

    <script src="<?php echo e(asset('js/pesanAdmin.js')); ?>"></script>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/pesan.blade.php ENDPATH**/ ?>