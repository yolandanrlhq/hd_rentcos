<?php $__env->startSection('title', 'Detail Produk - HD RENTCOS'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/jadwalEventUser.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="event-container">
        <h2>Jadwal Event</h2>

        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="event-card">
            <div class="event-info">
                <h3><?php echo e($event->nama_event); ?></h3>
                <div class="event-details">
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo e($event->tempat_event); ?></p>
                    <p><i class="fas fa-calendar-alt"></i> <?php echo e(date('Y-m-d', strtotime($event->tgl_event))); ?></p>                    <p><i class="fas fa-ticket-alt"></i> <?php echo e($event->htm); ?></p>
                    <p><i class="fas fa-phone-alt"></i> <?php echo e($event->kontak_panitia); ?></p>
                </div>
            </div>
            <div class="event-image">
                <?php if($event->gambar): ?>
                    <img src="<?php echo e(asset('storage/'.$event->gambar)); ?>" alt="<?php echo e($event->nama_event); ?>">
                <?php else: ?>
                    <div class="img-placeholder">Gambar Event</div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </main>
    <?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/jadwalEvent.blade.php ENDPATH**/ ?>