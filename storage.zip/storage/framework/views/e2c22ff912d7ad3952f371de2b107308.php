<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/pesanan.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <?php echo $__env->make('admin.sections.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main class="main-content">
        <section class="stat-cards-container">
            <div class="stat-card total">
                <div class="card-icon"><i class="fas fa-receipt"></i></div>
                <div class="card-info">
                    <span class="card-title">Total Pesanan</span>
                    <span class="card-value"><?php echo e($total); ?></span>
                </div>
                <button class="card-options"><i class="fas fa-ellipsis-v"></i></button>
            </div>

            <div class="stat-card success">
                <div class="card-icon"><i class="fas fa-user-check"></i></div>
                <div class="card-info">
                    <span class="card-title">Berhasil</span>
                    <span class="card-value"><?php echo e($berhasil); ?></span>
                </div>
                <button class="card-options"><i class="fas fa-ellipsis-v"></i></button>
            </div>

            <div class="stat-card failed">
                <div class="card-icon"><i class="fas fa-heart-broken"></i></div>
                <div class="card-info">
                    <span class="card-title">Gagal</span>
                    <span class="card-value"><?php echo e($gagal); ?></span>
                </div>
                <button class="card-options"><i class="fas fa-ellipsis-v"></i></button>
            </div>

            <div class="stat-card pending">
                <div class="card-icon"><i class="fas fa-clipboard-list"></i></div>
                <div class="card-info">
                    <span class="card-title">Dalam Proses</span>
                    <span class="card-value"><?php echo e($diproses + $pending + $dikirim); ?></span>
                </div>
                <button class="card-options"><i class="fas fa-ellipsis-v"></i></button>
            </div>
        </section>

        <section class="data-table-section">
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>id_sewa</th>
                            <th>nama</th>
                            <th>kostum</th>
                            <th>harga</th>
                            <th>tgl_sewa</th>
                            <th>tgl_kembali</th>
                            <th>status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $p->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->user->name ?? '-'); ?></td>
                            <td><?php echo e($item->produk->nama_produk ?? '-'); ?></td>
                            <td><?php echo e(number_format($item->sewa->total_harga,0,',','.')); ?></td>
                            <td><?php echo e($p->tanggal_sewa); ?></td>
                            <td><?php echo e($p->tanggal_kembali); ?></td>
                            <td>
                                <?php if(in_array($p->status, ['selesai','dibatalkan'])): ?>
                                    <span><?php echo e(ucfirst(str_replace('_',' ',$p->status))); ?></span>
                                <?php else: ?>
                                    <select class="status-select" data-id="<?php echo e($p->id); ?>">
                                        <option value="menunggu_konfirmasi" <?php echo e($p->status == 'menunggu_konfirmasi' ? 'selected' : ''); ?>>Menunggu Konfirmasi</option>
                                        <option value="diproses" <?php echo e($p->status == 'diproses' ? 'selected' : ''); ?>>Diproses</option>
                                        <option value="dikirim" <?php echo e($p->status == 'dikirim' ? 'selected' : ''); ?>>Dikirim</option>
                                        <option value="selesai" <?php echo e($p->status == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                                        <option value="dibatalkan" <?php echo e($p->status == 'dibatalkan' ? 'selected' : ''); ?>>Dibatalkan</option>
                                    </select>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>

        <div class="pagination-wrapper" style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
            <span class="table-count">
                <?php echo e($pesanan->firstItem() ?? 0); ?>-<?php echo e($pesanan->lastItem() ?? 0); ?> of <?php echo e($pesanan->total()); ?>

            </span>

            <div class="pagination-controls" style="display: flex; align-items: center; gap: 8px;">
                <span>Rows per page:</span>
                <span class="row-count">10</span>

                <?php if($pesanan->onFirstPage()): ?>
                    <button class="nav-button disabled"><i class="fas fa-angle-left"></i></button>
                <?php else: ?>
                    <a href="<?php echo e($pesanan->previousPageUrl()); ?>" class="nav-button"><i class="fas fa-angle-left"></i></a>
                <?php endif; ?>

                <?php if($pesanan->hasMorePages()): ?>
                    <a href="<?php echo e($pesanan->nextPageUrl()); ?>" class="nav-button"><i class="fas fa-angle-right"></i></a>
                <?php else: ?>
                    <button class="nav-button disabled"><i class="fas fa-angle-right"></i></button>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.querySelectorAll('.status-select').forEach(select => {
    select.addEventListener('change', function() {
        const sewaId = this.dataset.id;
        const newStatus = this.value;

        // ✅ Tambahkan console.log di sini
        console.log('Sewa ID yang diklik:', sewaId);
        console.log('Status yang dipilih:', newStatus);

        fetch(`/admin/pesanan/${sewaId}/status`, { // pastikan prefix admin sesuai route
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({ status: newStatus })
        })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                // replace select dengan text untuk semua status
                const text = newStatus.replace('_',' ').replace(/\b\w/g, l => l.toUpperCase());
                this.outerHTML = `<span>${text}</span>`;
            } else {
                alert('Gagal memperbarui status.');
            }
        })
        .catch(err => {
            console.error(err);
            alert('Terjadi kesalahan.');
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/admin/pesanan.blade.php ENDPATH**/ ?>