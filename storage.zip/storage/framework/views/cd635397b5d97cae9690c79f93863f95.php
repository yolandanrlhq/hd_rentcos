<?php $__env->startSection('title', 'Detail Produk - HD RENTCOS'); ?>
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/detailProduk.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="product-detail-section">
<div class="container">

    <!-- ================= PRODUK ================= -->
    <div class="grid-container">

        <!-- ===== GAMBAR ===== -->
        <div class="product-image">
            <?php if($produk->fotos->count() > 0): ?>
            <div class="slider-container">
                <img id="mainPhoto" src="<?php echo e(asset('storage/' . $produk->fotos->first()->foto_path)); ?>" alt="<?php echo e($produk->nama_produk); ?>">
                <div class="slider-controls">
                    <button type="button" id="prevBtn">&#10094;</button>
                    <button type="button" id="nextBtn">&#10095;</button>
                </div>
                <div class="thumbnail-container">
                    <?php $__currentLoopData = $produk->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="thumbnail" src="<?php echo e(asset('storage/' . $foto->foto_path)); ?>" alt="<?php echo e($produk->nama_produk); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php else: ?>
            <img src="<?php echo e(asset('storage/' . $produk->foto)); ?>" alt="<?php echo e($produk->nama_produk); ?>">
            <?php endif; ?>
        </div>

        <!-- ===== INFO PRODUK ===== -->
        <div class="product-info">
            <h1><?php echo e($produk->nama_produk); ?></h1>

            <!-- WISHLIST -->
            <div class="wishlist-btn-wrapper">
                <button type="button" class="wishlist-btn" id="wishlistBtn" data-produk="<?php echo e($produk->id_produk); ?>">
                    <i class="<?php echo e($isWishlisted ? 'fas' : 'far'); ?> fa-heart"></i>
                </button>
            </div>

            <!-- RATING -->
            <div class="rating">
                <?php
                    $avg = round($produk->testimonis?->avg('rating') ?? 0,1);
                    $total = $produk->testimonis?->count() ?? 0;
                    $full = floor($avg);
                    $half = ($avg - $full) >= 0.5;
                ?>

                <?php for($i=0;$i<$full;$i++): ?> <i class="fas fa-star"></i> <?php endfor; ?>
                <?php if($half): ?> <i class="fas fa-star-half-alt"></i> <?php endif; ?>
                <?php for($i=$full+($half?1:0);$i<5;$i++): ?> <i class="far fa-star"></i> <?php endfor; ?>

                <span>(<?php echo e($avg); ?>/5 dari <?php echo e($total); ?> ulasan)</span>
            </div>

            <div class="price-row">
                <span class="price">Rp<?php echo e(number_format($produk->harga_produk,0,',','.')); ?></span>
                <span class="duration">/ 3 hari</span>
            </div>

            <!-- UKURAN -->
            <div class="ukuran-buttons">
                <?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button"
                    class="ukuran-btn <?php echo e(($detail['stok']==0 || $detail['is_rented']) ? 'disabled':''); ?>"
                    data-ukuran="<?php echo e($ukuran); ?>"
                    data-stok="<?php echo e($detail['stok']); ?>"
                    <?php echo e(($detail['stok']==0 || $detail['is_rented']) ? 'disabled':''); ?>>
                    <?php echo e($ukuran); ?>

                </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div id="infoStok" class="info-stok"></div>

            <!-- CART -->
            <form id="cartForm" action="<?php echo e(route('cart.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_produk" value="<?php echo e($produk->id_produk); ?>">
                <input type="hidden" name="ukuran" id="selectedSize">
                <input type="hidden" name="jumlah" id="selectedQty" value="1">

                <div class="cart-actions">
                    <div class="quantity-box">
                        <button type="button" id="minusBtn">−</button>
                        <span id="qtyDisplay">1</span>
                        <button type="button" id="plusBtn" class="disabled">+</button>
                    </div>

                    <button type="submit" id="addCartBtn" class="add-cart-btn disabled" disabled>
                        + Tambah ke Keranjang
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- ================= TAB ================= -->
    <section class="tab-section">
        <div class="tab-buttons">
            <button class="active">Detail Produk</button>
            <button>Ulasan</button>
            <button>FAQ</button>
        </div>

        <div class="tab-content active">
            <p><?php echo e($produk->deskripsi ?? 'Belum ada deskripsi produk.'); ?></p>
        </div>

        <div class="tab-content">
            <?php if($produk->testimonis && $produk->testimonis->count() > 0): ?>
                <?php $__currentLoopData = $produk->testimonis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="testimoni-bubble">
                    <strong><?php echo e($testi->sewa->user->name ?? 'User'); ?></strong>
                    <p><?php echo e($testi->isi); ?></p>
                    <small>Rating: <?php echo e($testi->rating); ?> ⭐</small>
                    <?php if($testi->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $testi->foto)); ?>" alt="Foto testimoni" class="testimoni-foto">
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Belum ada ulasan.</p>
            <?php endif; ?>
        </div>

        <div class="tab-content"><p>Tidak ada pertanyaan.</p></div>
    </section>

    <!-- ================= REKOMENDASI ================= -->
    <div class="rekomendasi">
        <h2>Produk Serupa</h2>
        <div class="rekomendasi-grid">
            <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('user.produk.show',$item->id_produk)); ?>" class="rekomendasi-item">
                <img src="<?php echo e(asset('storage/' . $item->foto)); ?>">
                <h3><?php echo e($item->nama_produk); ?></h3>
                <p>Rp<?php echo e(number_format($item->harga_produk,0,',','.')); ?></p>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</main>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
document.addEventListener('DOMContentLoaded', () => {
    /* TAB */
    const tabBtns = document.querySelectorAll('.tab-buttons button');
    const tabs = document.querySelectorAll('.tab-content');
    tabBtns.forEach((btn,i)=>btn.onclick=()=>{
        tabBtns.forEach(b=>b.classList.remove('active'));
        tabs.forEach(t=>t.classList.remove('active'));
        btn.classList.add('active'); tabs[i].classList.add('active');
    });

    /* UKURAN & CART */
    let qty=1,max=0;
    const info=document.getElementById('infoStok');
    const qtyDisp=document.getElementById('qtyDisplay');
    const plus=document.getElementById('plusBtn');
    const minus=document.getElementById('minusBtn');
    const sizeInput=document.getElementById('selectedSize');
    const qtyInput=document.getElementById('selectedQty');
    const addBtn=document.getElementById('addCartBtn');

    document.querySelectorAll('.ukuran-btn').forEach(btn=>{
        btn.onclick=()=>{
            if(btn.classList.contains('disabled')) return;
            document.querySelectorAll('.ukuran-btn').forEach(b=>b.classList.remove('active'));
            btn.classList.add('active');
            max=parseInt(btn.dataset.stok);
            sizeInput.value=btn.dataset.ukuran;
            qty=1; qtyDisp.textContent=1; qtyInput.value=1;
            info.textContent=`Stok tersedia: ${max}`;
            addBtn.disabled=false; addBtn.classList.remove('disabled');
            plus.disabled=max<=1;
        }
    });

    plus.onclick=()=>{ if(qty<max){qty++;qtyDisp.textContent=qty;qtyInput.value=qty;} };
    minus.onclick=()=>{ if(qty>1){qty--;qtyDisp.textContent=qty;qtyInput.value=qty;} };

    /* WISHLIST */
    const wishBtn=document.getElementById('wishlistBtn');
    if(wishBtn){
        wishBtn.onclick=async()=>{
            const res=await fetch("<?php echo e(route('wishlist.toggle')); ?>",{
                method:'POST',headers:{'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>','Content-Type':'application/json'},
                body:JSON.stringify({id_produk:wishBtn.dataset.produk})
            });
            if(res.status===401){location.href="<?php echo e(route('login')); ?>";return;}
            const data=await res.json();
            const icon=wishBtn.querySelector('i');
            icon.classList.toggle('fas',data.status==='added');
            icon.classList.toggle('far',data.status==='removed');
        }
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/detailProduk.blade.php ENDPATH**/ ?>