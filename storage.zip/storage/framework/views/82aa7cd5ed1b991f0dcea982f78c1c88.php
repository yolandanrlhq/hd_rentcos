<?php $__env->startSection('title', 'Detail Pesanan - HD RENTCOS'); ?>
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/status.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.sections.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="status-page">
    <div class="status-container">
        <h2>Detail Pesanan #<?php echo e($sewa->kode_pesanan); ?></h2>

        <?php $__currentLoopData = $sewa->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="status-card">
            <div class="status-left">
                <img src="<?php echo e($item->produk ? asset('storage/' . $item->produk->foto) : asset('storage/default.jpg')); ?>" alt="">
                <div>
                    <h3><?php echo e(optional($item->produk)->nama_produk ?? 'Produk tidak tersedia'); ?></h3>
                    <p>Ukuran: <strong><?php echo e($item->ukuran); ?></strong></p>
                    <p>Jumlah: <strong><?php echo e($item->jumlah); ?></strong></p>
                    <p>Total: <strong>Rp<?php echo e(number_format($item->subtotal,0,',','.')); ?></strong></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="btn-wrapper" style="margin-top: 15px;">
            <?php if(in_array($sewa->status, ['dikirim', 'diproses'])): ?>
            <form action="<?php echo e(route('cart.complete', $sewa->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn-complete">Pesanan Selesai</button>
            </form>
            <?php endif; ?>

            <?php if(in_array($sewa->status, ['pending','menunggu_konfirmasi','diproses'])): ?>
            <form action="<?php echo e(route('cart.cancel', $sewa->id)); ?>" method="POST" style="margin-top: 5px;">
                <?php echo csrf_field(); ?>
                <button class="btn-cancel">Batalkan Pesanan</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php echo $__env->make('user.sections.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LARAGON\laragon6\www\hd_rentcos\resources\views/user/detail.blade.php ENDPATH**/ ?>